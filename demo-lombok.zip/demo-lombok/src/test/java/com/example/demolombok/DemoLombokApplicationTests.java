package com.example.demolombok;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoLombokApplicationTests {

	@Test
	void contextLoads() {
	}

}
