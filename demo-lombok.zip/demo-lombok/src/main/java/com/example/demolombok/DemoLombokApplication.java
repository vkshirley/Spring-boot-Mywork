package com.example.demolombok;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoLombokApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoLombokApplication.class, args);
	}

}
