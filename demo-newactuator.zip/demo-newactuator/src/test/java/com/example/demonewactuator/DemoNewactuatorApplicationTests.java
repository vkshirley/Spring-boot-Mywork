package com.example.demonewactuator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoNewactuatorApplicationTests {

	@Test
	void contextLoads() {
	}

}
