package com.example.demonewactuator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoNewactuatorApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoNewactuatorApplication.class, args);
	}

}
