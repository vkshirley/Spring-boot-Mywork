package com.java.exceptionhandling;

public class MultipleResourceFound extends Exception {

	public MultipleResourceFound() {
		super();
	}

	public MultipleResourceFound(final String message) {
		super(message);
	}
}
