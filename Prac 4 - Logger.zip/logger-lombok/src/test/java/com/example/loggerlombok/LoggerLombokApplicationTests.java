package com.example.loggerlombok;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoggerLombokApplicationTests {

	@Test
	void contextLoads() {
	}

}
