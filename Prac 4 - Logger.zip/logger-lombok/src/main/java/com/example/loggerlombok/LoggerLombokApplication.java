package com.example.loggerlombok;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoggerLombokApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoggerLombokApplication.class, args);
	}

}
