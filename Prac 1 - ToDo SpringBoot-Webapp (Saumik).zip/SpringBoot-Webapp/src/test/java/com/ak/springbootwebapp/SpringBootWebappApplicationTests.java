package com.ak.springbootwebapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootWebappApplicationTests {

	@Test
	void contextLoads() {
	}

}
